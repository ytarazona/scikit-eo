"""Top-level package for scikit-eo."""

__author__ = """Yonatan Tarazona Coronel"""
__email__ = 'geoyons@gmail.com'
__version__ = '0.1.0'
